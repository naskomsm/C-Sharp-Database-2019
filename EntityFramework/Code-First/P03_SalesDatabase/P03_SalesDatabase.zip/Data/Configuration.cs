﻿namespace P03_SalesDatabase.Data
{
    internal class Configuration
    {
        internal const string ConnectionString = @"Server=.;Database=SalesDatabase;Integrated Security=True;";
    }
}
